#ifndef __FUNCTION_H__
#define __FUNCTION_H__

int incorrectInput(int input);
void firstInterface();
void stuEntrance();
void stuLogin();
void stuRegister();
void stuOperation(struct stu *);
void borrow(struct stu *);
void returnbook(struct stu*);
void staffEntrance();
void adminLogin();
void adminRegister();
void staffFunction();
void addbook();
void deletebook();
void viewstudents();
void details();
void change();
void addpassword();
int stuExist(char *);
int pwExist(char *);
int bookExist(char *);
void writefile(int);
void writeStudents();
void writeBooks();
void readStudents();
void readBooks();
void readPassword();
#endif
